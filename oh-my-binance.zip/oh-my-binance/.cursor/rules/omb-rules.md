---
description: Oh My Binance — Binance Agent OS crypto research library
globs: ["**/*"]
alwaysApply: false
---
# Oh My Binance rules (Cursor)

When the user asks any crypto/market/token/wallet question inside this workspace:

1. Read `AGENTS.md` at the repo root FIRST — it is the bootstrap guide.
2. Route via `skills/crypto-research-orchestrator/SKILL.md`.
3. Data source is Binance Agent OS MCP (read-only). Never fall back to public REST.
4. Web3/token/wallet data: invoke `vendors/binance-web3/<name>/scripts/cli.mjs`
   (`node <cli> <command> '<json>'`; `--check` reports dependency/auth status).
5. Missing Data Silence Rule: unavailable data/capability -> omit from user-facing output entirely; record MISSING/UNSUPPORTED internally only. Never fabricate. Exception: user explicitly asks if a data point is available.
6. Evidence contract: `schemas/evidence-contract.yaml` (OBSERVED/INFERRED/POSSIBLE/UNKNOWN; CONFIDENCE footer lowercase).
7. Research only — no BUY/SELL instructions.
