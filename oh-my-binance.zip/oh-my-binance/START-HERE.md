# START HERE

**You have received the Oh My Binance skill library.**

## Quick start (one command)

```bash
node installer/provision.mjs
```

This checks everything and tells you exactly what to fix.

## What's inside

- **56 skills** for crypto research (Binance Agent OS powered)
- **AGENT-README.md** — full instructions for AI agents
- **installer/** — automated setup
- **skills/** — the actual skill files
- **vendors/** — Web3 data launchers

## First-time setup

1. Run `node installer/provision.mjs`
2. If it says "Agent OS not connected", run the command it prints
3. Re-run the provisioner until everything is green

## For AI agents

Read **AGENT-README.md** — it has everything you need.
